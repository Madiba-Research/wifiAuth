"""Two independently computed RoomLock results; CPU inference only."""
import argparse, collections, hashlib, json, re, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
TEST_USERS=['t14','t16','t17','t18','t19','t20','t22','t23','t24']
def rows(group):
    name='tables' if group=='small_ab' else 'test'
    return [json.loads(line) for line in (ROOT/'data'/f'{name}.jsonl').open()]
def selected_large():
    data=rows('large_cde')
    return [r for r in data if r['operation']=='register'], [r for r in data if r['operation']=='authenticate']
def table_b():
    data=[r for r in rows('small_ab') if r['source']=='log_auth_distance/auth_app_20250707_161418_d1p1.log']
    output=[]
    expected=[(157,115.6,109,126,41.0,81,30,3),(148,124.0,122,128,5.2,97,23,3),(275,210.8,202,220,36.6,161,21,2),(361,288.2,277,297,45.8,222,22,2),(303,237.4,226,243,34.6,169,23,2)]
    for i in range(5):
        name=f't{i}d1p1'; batches=[r['aps'] for r in data if r['username']==name]
        sets=[{ap['bssid'] for scan in b for ap in scan} for b in batches]
        n=list(map(len,sets));mean=sum(n)/len(n); inter=set.intersection(*sets)
        values=collections.defaultdict(list)
        for b in batches:
            for scan in b:
                for ap in scan:
                    if ap['bssid'] in inter:values[ap['bssid']].append(ap['rssi'])
        ranges=[max(v)-min(v) for v in values.values()]
        result=(len(set.union(*sets)),round(mean,1),min(n),max(n),round(sum((x-mean)**2 for x in n)/len(n),1),len(inter),max(ranges),min(ranges))
        assert result==expected[i],(name,result,expected[i])
        output.append(dict(user=name,total=result[0],average=result[1],minimum=result[2],maximum=result[3],variance=result[4],intersection=result[5],max_rssi_range=result[6],min_rssi_range=result[7]))
    return {'claim':'VI-B Tables I and II','status':'matches paper numeric statistics','rows':output}

def profile_name(u):
    return re.match(r't\d+',u).group()+'d3'+u[-2:]

def replay(args):
    import numpy as np
    import torch
    from models.Encoderfuzzy3 import GNNEncoder,TripletNet
    from utils.ProcessRawData import create_pyg_graph
    from fuzzyVerifier import RadiusAdaptedFuzzyVerifier
    from user import User
    base=Path(__file__).resolve().parent
    model=GNNEncoder(6,64,32)
    wrapper=TripletNet(model)
    checkpoint=torch.load(base/'best_630d3norm_hnm_meanpool_a4_random.pth',map_location='cpu',weights_only=True)
    wrapper.load_state_dict(checkpoint['model_state_dict']);model.eval()
    verifier=RadiusAdaptedFuzzyVerifier(str(base/'H_G_demo_32_dimension.npz'))
    torch.set_num_threads(args.threads)
    def encode(scan):
        g=create_pyg_graph(scan,None)
        with torch.no_grad():return model(g.x,g.edge_index,torch.zeros(g.num_nodes,dtype=torch.long),g.edge_attr)[0].numpy()
    if args.command=='smoke':
        _,auth=selected_large();scan=auth[0]['aps'][0]
        a=encode(scan);b=encode(list(reversed(scan)))
        assert a.shape==(32,) and np.isfinite(a).all()
        assert np.allclose(a,b,rtol=1e-4,atol=1e-4)
        return {'status':'PASS','checks':['checkpoint loaded','real scan encoded to finite 32-vector','AP-order invariance within float tolerance'],'max_order_difference':float(np.max(np.abs(a-b)))}
    reg,auth=selected_large();split={'test': TEST_USERS}
    users=set(split['evaluation']+split['test'] if args.split=='all' else split[args.split])
    reg=[r for r in reg if re.match(r't\d+',r['username']).group() in users]
    auth=[r for r in auth if re.match(r't\d+',r['username']).group() in users]
    profiles={};hashes={}
    def digest(x):return hashlib.sha256(np.asarray(x,dtype=np.float32).tobytes()).hexdigest()
    start=time.perf_counter()
    for r in reg:
        u=profile_name(r['username']);user=User(u)
        xs=np.array([encode(s) for s in r['aps']])
        verifier.register(user,xs,sigma=args.sigma)
        profiles[u]=user;hashes[u]=digest(user.user_passwd)
        print('Registered',u,flush=True)
    decisions=[]
    for r in auth:
        u=profile_name(r['username']);y=np.mean(np.array([encode(s) for s in r['aps']]),axis=0)
        other=u[:-2]+('p7' if u.endswith('p1') else 'p1')
        for target,kind in [(u,'genuine'),(other,'impostor')]:
            ok=digest(verifier.authenticate_calc(profiles[target],y))==hashes[target]
            decisions.append(dict(source=r['source'],source_line=r['source_line'],observed_profile=u,target_profile=target,kind=kind,accepted=ok))
    genuine=[d for d in decisions if d['kind']=='genuine'];imp=[d for d in decisions if d['kind']=='impostor']
    tp=sum(d['accepted'] for d in genuine);fp=sum(d['accepted'] for d in imp);fn=len(genuine)-tp
    return dict(command='fixed-state-replay',split=args.split,sigma=args.sigma,registered_profiles=len(profiles),genuine_count=len(genuine),impostor_count=len(imp),tar=tp/len(genuine),frr=fn/len(genuine),far=fp/len(imp),f1=2*tp/(2*tp+fp+fn),seconds=time.perf_counter()-start,decisions=decisions,note='New inference results. Compare with the paper; do not assume exact agreement. States are held in memory and never adapted.')
def main():
    import contextlib, platform, resource
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,default=Path('results'))
    a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=False)
    start=time.perf_counter()
    tables=table_b()
    args=argparse.Namespace(command='replay',split='test',sigma=1.185,threads=1)
    with (a.output/'run.log').open('w') as log,contextlib.redirect_stdout(log):
        metrics=replay(args)
    assert metrics['genuine_count']==90 and metrics['impostor_count']==90
    reference={'far':8/90,'frr':3/90,'f1':174/185}
    matches=all(abs(metrics[k]-v)<1e-6 for k,v in reference.items())
    tables['note']='Computed from raw scans; paper numeric table values checked by assertions.'
    (a.output/'tables.json').write_text(json.dumps(tables,indent=2)+'\n')
    (a.output/'authentication.json').write_text(json.dumps(metrics,indent=2)+'\n')
    peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    info={'elapsed_seconds':time.perf_counter()-start,'peak_rss_bytes':peak if platform.system()=='Darwin' else peak*1024,'platform':platform.platform(),'python':sys.version,'matches_paper':matches}
    (a.output/'runtime.json').write_text(json.dumps(info,indent=2)+'\n')
    print('Tables I/II: PASS')
    print(f"FAR: {metrics['far']:.4%}; FRR: {metrics['frr']:.4%}; F1: {metrics['f1']:.6f}")
    print('Paper metrics:', 'PASS' if matches else 'DIFFER; inspect outputs and environment')
    print(json.dumps(info,indent=2))
    if not matches: raise SystemExit(2)
if __name__=='__main__': main()
