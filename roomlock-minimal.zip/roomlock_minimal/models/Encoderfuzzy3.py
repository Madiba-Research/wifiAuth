import torch
import torch.nn as nn
from torch_geometric.nn import TransformerConv, global_mean_pool

class GNNEncoder(torch.nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super().__init__()

        # self.conv1 = GCNConv(input_dim, hidden_dim)
        # self.conv2 = GCNConv(hidden_dim, hidden_dim)
        # self.conv3 = GCNConv(hidden_dim, output_dim)

        self.conv1 = TransformerConv(input_dim, hidden_dim, edge_dim=1)
        self.conv2 = TransformerConv(hidden_dim, hidden_dim, edge_dim=1)
        self.conv3 = TransformerConv(hidden_dim, hidden_dim, edge_dim=1)
        self.conv4 = TransformerConv(hidden_dim, output_dim, edge_dim=1)
        # self.conv4 = TransformerConv(hidden_dim, output_dim // 2, edge_dim=1)

        

        self.bn1 = torch.nn.BatchNorm1d(hidden_dim)
        self.bn2 = torch.nn.BatchNorm1d(hidden_dim)
        self.bn3 = torch.nn.BatchNorm1d(hidden_dim)
        # self.pool = global_add_pool

        # for log_auth_distance_sigma2_norm_hn
        # self.pool = global_mean_pool

        # for log_auth_alpha15
        # self.pool = global_max_pool
        self.pool = global_mean_pool

    def forward(self, x, edge_index, batch, edge_attr=None):
        if edge_attr is None:
            raise ValueError("edge_attr is required for this model")

        x = self.conv1(x, edge_index, edge_attr).relu()
        x = self.bn1(x)

        x = self.conv2(x, edge_index, edge_attr).relu()
        x = self.bn2(x)
        x = self.conv3(x, edge_index, edge_attr).relu()

        x = self.bn3(x)
        x = self.conv4(x, edge_index, edge_attr)

        # x = x + self.conv2(x, edge_index)
        # x = x + self.conv3(x, edge_index)
        
        # graph_embedding = global_mean_pool(x, batch)
        # for both log_auth_distance_sigma2_norm_hn and log_auth_alpha15
        graph_embedding = self.pool(x, batch)

        # mean_pool = global_mean_pool(x, batch)
        # max_pool = global_max_pool(x, batch)
        # graph_embedding = torch.cat([mean_pool, max_pool], dim=1)

        return graph_embedding

class TripletNet(nn.Module):
    def __init__(self, embedding_net):
        super(TripletNet, self).__init__()
        self.embedding_net = embedding_net

    # def forward(self, x1, x2, x3):
    #     output1 = self.embedding_net(x1)
    #     output2 = self.embedding_net(x2)
    #     output3 = self.embedding_net(x3)
    #     return output1, output2, output3

    def forward(self, g1, g2, g3):
        output1 = self.embedding_net(g1.x, g1.edge_index, g1.batch, g1.edge_attr)
        output2 = self.embedding_net(g2.x, g2.edge_index, g2.batch, g2.edge_attr)
        output3 = self.embedding_net(g3.x, g3.edge_index, g3.batch, g3.edge_attr)
        return output1, output2, output3

    def get_embedding(self, x):
        return self.embedding_net(x)
