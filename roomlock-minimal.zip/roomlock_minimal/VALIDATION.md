# Validation

Both results were recomputed successfully in an isolated local virtual environment, without access to the original project at runtime.

- macOS arm64, Python 3.12.14
- Torch 2.6.0, PyTorch Geometric 2.6.1, NumPy 1.26.4
- CPU, one Torch thread; no GPU, database, server or model training
- Tables I/II: all five numeric rows match
- Fresh raw-scan registration/test: FAR 8/90 = 8.8889%, FRR 3/90 = 3.3333%, F1 0.940541
- Evaluation including Python imports/model loading: approximately 4.2 seconds in the measured run (excluding dependency installation)
- Peak process RSS: approximately 305 MiB; installed local virtual environment: approximately 544 MiB on this macOS host
- Package payload is approximately 8 MiB before compression. Dependency download/cache disk space is additional and platform-dependent.

Linux/public research infrastructure and other architectures have not been tested. These local measurements are not universal minimum requirements. NumPy 1.26.4 was selected after NumPy 2.0.1 emitted matrix-operation warnings on this host; the final tested version runs without those warnings.
