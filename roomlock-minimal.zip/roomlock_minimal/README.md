# RoomLock: minimal two-result reproduction

CPU-only, pretrained inference. No Android device, model training, Flask server, existing database or paid API is needed.

## Install and run

Use Python 3.10–3.12 on Linux or macOS. From the extracted folder:

```sh
./install.sh
.venv/bin/python run.py --output results
```

Use a new output directory for each run. Installation needs internet; evaluation uses local files only. CPU only; one Torch thread.

## Results and scope

1. VI-B Tables I/II: recompute all five locations' AP counts, intersections and extreme RSSI ranges from 25 recorded authentication batches.
2. VI-D final-threshold test result / VI-E Table III RoomLock row: register 18 location profiles from raw scans, evaluate 90 genuine and 90 impostor decisions using the pretrained 32-dimensional encoder and sigma=1.185. Expected FAR 8.89%, FRR 3.33%, F1 0.940541.

The runner writes tables.json, authentication.json (including individual decisions and source references), runtime.json and run.log. Assertions compare independently computed results with paper values; the paper's values are not substituted for predictions. Runtime reports peak process RSS and elapsed evaluation time including imports/model loading, but excludes dependency installation.

This package does not reproduce threshold selection, the full Figure 4 curves, other baselines, VI-A/C, spoofing experiments, long-term adaptation, Android deployment or Trusted Places field measurements.

## Data and provenance

- data/tables.jsonl: source log_auth_distance/auth_app_20250707_161418_d1p1.log; 5 locations, 5 batches each.
- data/test.jsonl: source another20loc/auth_app_20251116_144836.log and auth_app_20251117_144632.log. Test identifiers t14,t16,t17,t18,t19,t20,t22,t23,t24; positions p1/p7. Exactly 18 registrations of 59 scans and 90 test batches of 19 scans. The paper describes 60/20 configured scans; this package preserves actual recorded batches without fabricating missing scans.
- Every record includes the original source path and line. Only raw BSSID/RSSI scan data, operation, username and provenance are retained; historical embeddings/decisions are not inference inputs.
- Checkpoint best_630d3norm_hnm_meanpool_a4_random.pth and H_G_demo_32_dimension.npz are copied from the research project. Encoderfuzzy3.py retains only the original GNNEncoder and TripletNet classes; verifier, user and preprocessing code are copied from the original project.

Paper: RoomLock: Fine-Grained Trusted-Place Device Authentication with Ambient WiFi Fingerprints (ACSAC 2026).

No additional license is assigned by this packaging step. Raw Wi-Fi identifiers are retained to preserve the trained representation; they are not anonymized. See VALIDATION.md for the environment actually tested.
